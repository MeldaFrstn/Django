"""
This is a comment
written in
more than just a line
"""
#print("Hello World!")

x = 5
y = "john"
print(type(x))
print(type(y))